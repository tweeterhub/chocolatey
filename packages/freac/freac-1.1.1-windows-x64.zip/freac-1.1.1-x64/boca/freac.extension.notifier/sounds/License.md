The sound files in this folder are licensed by Little Robot Sound Factory under the [Creative Commons Attribution License](https://creativecommons.org/licenses/by/3.0/).
## Sound files
- finished.flac - [freesound.org](https://freesound.org/people/LittleRobotSoundFactory/sounds/270528/), converted to 44.1 kHz, 16 bit FLAC format
