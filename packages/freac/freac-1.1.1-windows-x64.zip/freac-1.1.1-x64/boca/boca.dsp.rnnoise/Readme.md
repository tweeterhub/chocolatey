## RNNoise Model Files

These RNNoise model files have been trained by Gregor Richards and kindly made
available in the public domain at https://github.com/GregorR/rnnoise-models.
